%Eland Anthony; CS461-001; Homework2; 03-30-21%

global totalEpochs
totalEpochs = 109;

global sampleRate
sampleRate = 220;

eeglab

saveEpochs(3,4)
compareBandPower(32)
getHighestAlpha()



% Create a matlab function that generates and saves line plots of 3 epochs
% (4 channels per epoch). The function should save a total of 12 images.
function saveEpochs(numEpochs, numChannels)

% Importing EEG Data
EEG = pop_loadset('filename', 'p1.set', 'filepath', pwd );

% Edit Channels
EEG = pop_chanedit(EEG, 'changefield',{1 'labels' 'TP9'}, 'changefield',{2 'labels' 'AF7'},'changefield',{3 'labels' 'AF8'}, 'changefield', {4 'labels' 'TP10'});

%Define variables
%epochIndex = 1;
%channelNumber = 3;
sampleRate = 220;
counter = 0;

% Plot each Epoch
for j = 1:numChannels
    for k = 1:numEpochs
        x = (1:sampleRate)*(1000/sampleRate);
        epoch = EEG.data(j,:,k); % ':' is every sample ie [220]

        figure
        plot(x, epoch)
        counter = counter + 1;
        saveas(gcf,[num2str(counter) '-ElandsPlot.png'])
    end
end
end

%---------------------------------------------------------------------%

% Complete the function below to generate 4 bar plots that compares delta, theta, alpha, and beta band
% power of 1 epoch. Each bar plot should reflect a different channel.
function compareBandPower(epochNumber)
sampleRate = 220;
channelNumber = 1;

% Importing EEG Data
EEG = pop_loadset('filename', 'p1.set', 'filepath', pwd );

% Edit Channels
EEG = pop_chanedit(EEG, 'changefield',{1 'labels' 'TP9'}, 'changefield',{2 'labels' 'AF7'},'changefield',{3 'labels' 'AF8'}, 'changefield', {4 'labels' 'TP10'});

%Calsulate epoch, pxx, and freq
epoch = EEG.data(channelNumber,:,epochNumber);
[pxx, freq] = pwelch(epoch, [],[], [], sampleRate);

%Identify powers for each band
alpha = bandpower(pxx, freq, [9 14], 'psd');
beta = bandpower(pxx, freq, [15 30], 'psd');
theta = bandpower(pxx, freq, [4 8], 'psd');
delta = bandpower(pxx, freq, [1 3], 'psd');

% Plot Band Power (Bar Plot)
x = categorical({'Alpha', 'Beta', 'Theta', 'Delta'});
x = reordercats(x,{'Delta', 'Theta', 'Beta', 'Alpha'});
y = [alpha beta theta delta];

% Create Figure
figure
bar(x,y)
title(['Channel ' num2str(channelNumber)])

% Save plot
saveas(gcf,'NumberTwo.png')
end

%---------------------------------------------------------------------%

% Create a matlab function that finds the epoch with the highest alpha
% power in channel. The function should print out the epoch number and
% alpha value.
function getHighestAlpha()
sampleRate = 220;
alpha1 = 0;
    
EEG = pop_loadset('filename', 'p1.set', 'filepath', pwd );

% Edit Channels
EEG = pop_chanedit(EEG, 'changefield',{1 'labels' 'TP9'}, 'changefield',{2 'labels' 'AF7'},'changefield',{3 'labels' 'AF8'}, 'changefield', {4 'labels' 'TP10'});
%Loop through epochs and determine highest alpha power
for i = 1:109
    epoch = EEG.data(1,:,i);
    [pxx, freq] = pwelch(epoch, [],[], [], sampleRate);
    alpha = bandpower(pxx, freq, [9 14], 'psd');
    if alpha > alpha1
        alpha1 = alpha;
        result = alpha;
        position = i;
    end
end
%Display power and epoch
disp(result);
disp(position);
end
